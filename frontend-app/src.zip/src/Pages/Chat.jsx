import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { io } from "socket.io-client";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import AllContacts from "../Components/AllContacts";
import { allUsersRoute, host } from "../utils/apiRoutes";
import Welcome from "../Components/Welcome";
import ChatContainer from "../Components/ChatContainer";

const Chat = () => {
  const navigate = useNavigate();
  const socket = useRef(null);
  const [currentUser, setCurrentUser] = useState(undefined);
  const [currentChat, setCurrentChat] = useState(undefined);
  const [contacts, setContacts] = useState([]);

  // 1. Check if user is logged in
  useEffect(() => {
    const fetchUser = () => {
      try {
        const storedUser = localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY);
        if (!storedUser) {
          navigate("/login");
        } else {
          const user = JSON.parse(storedUser);
          if (!user || !user._id) {
            navigate("/login");
          } else {
            setCurrentUser(user);
          }
        }
      } catch (err) {
        console.error("Failed to parse user data:", err);
        navigate("/login");
      }
    };
    fetchUser();
  }, [navigate]);

  // 2. Initialize socket connection when user is set
  useEffect(() => {
    if (currentUser?._id) {
      socket.current = io(host);
      socket.current.emit("add-user", currentUser._id);

      return () => {
        // Cleanup socket on component unmount or user change
        if (socket.current) {
          socket.current.disconnect();
        }
      };
    }
  }, [currentUser]);

  // 3. Fetch all contacts
  useEffect(() => {
    const fetchContacts = async () => {
      if (currentUser?._id) {
        try {
          const { data } = await axios.get(`${allUsersRoute}/${currentUser._id}`);
          setContacts(data);
        } catch (error) {
          console.error("Failed to fetch contacts:", error);
        }
      }
    };
    fetchContacts();
  }, [currentUser]);

  const handleChangeChat = (chat) => {
    setCurrentChat(chat);
  };

  return (
    <Container>
      <div className="container">
        <AllContacts contacts={contacts} changeChat={handleChangeChat} />
        {currentChat === undefined ? (
          <Welcome />
        ) : (
          <ChatContainer currentChat={currentChat} socket={socket} />
        )}
      </div>
    </Container>
  );
};

const Container = styled.div`
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 1rem;
  align-items: center;
  background-color: #131324;
  .container {
    height: 85vh;
    width: 85vw;
    background-color: #00000076;
    display: grid;
    grid-template-columns: 25% 75%;
    @media screen and (min-width: 720px) and (max-width: 1080px) {
      grid-template-columns: 35% 65%;
    }
  }
`;

export default Chat;
