import React, { useState, useEffect } from "react";
import styled from "styled-components";
import HelloBee from "./HelloBee.png";

const Welcome = () => {
  const [userName, setUserName] = useState("");

  useEffect(() => {
    const fetchUserName = async () => {
      try {
        const storedUser = localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY);
        if (storedUser) {
          const user = JSON.parse(storedUser);
          setUserName(user.username || "Bee");
        }
      } catch (error) {
        console.error("Error fetching username:", error);
      }
    };
    fetchUserName();
  }, []);

  return (
    <Container>
      <img src={HelloBee} alt="Hello" />
      <h1>
        Helloooo!! <span>{userName}...</span>
      </h1>
      <p>Please select a contact to start buzzy chatting.</p>
    </Container>
  );
};

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  flex-direction: column;
  text-align: center;
  padding: 1rem;

  img {
    height: 15rem;
    margin-bottom: 1rem;
  }

  h1 {
    font-size: 2rem;
    margin-bottom: 0.5rem;
  }

  span {
    color: darkgreen;
  }

  p {
    font-size: 1.1rem;
    opacity: 0.8;
  }
`;

export default Welcome;
