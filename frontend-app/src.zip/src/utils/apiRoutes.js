// export const host = "http://localhost:8000";
// export const registerRoute =  `${host}/api/auth/register`;
// export const logOutRoute = `${host}/api/auth/logout`;
// export const allUsersRoute = `${host}/api/auth/allusers`;
// export const loginRoute = `${host}/api/auth/login`;
// export const sendMessageRoute = `${host}/api/auth/addmsg`;
// export const recieveMessageRoute = `${host}/api/auth/getmsg`;


export const host = "http://localhost:8000";
export const registerRoute = `${host}/api/auth/register`;
export const logOutRoute = `${host}/api/auth/logout`;
export const allUsersRoute = `${host}/api/auth/allusers`;
export const loginRoute = `${host}/api/auth/login`;
export const sendMessageRoute = `${host}/api/message/addmsg`; // FIXED
export const recieveMessageRoute = `${host}/api/message/getmsg`; // FIXED
